// Creates the database and tables from database.sql. Run once on a new server.
const fs = require('fs'); const path = require('path'); const mysql = require('mysql2/promise');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
(async () => {
  const sql = fs.readFileSync(path.join(__dirname, '..', 'database.sql'), 'utf8').replace(/ddeo_sratms/g, process.env.DB_NAME || 'ddeo_sratms');
  const conn = await mysql.createConnection({ host: process.env.DB_HOST, port: process.env.DB_PORT, user: process.env.DB_ADMIN_USER, password: process.env.DB_ADMIN_PASSWORD, multipleStatements: true });
  await conn.query(sql); await conn.end();
  console.log('Database ready. Remember to GRANT the app user (DB_USER) privileges on this database only.');
})().catch((e) => { console.error(e.message); process.exit(1); });
