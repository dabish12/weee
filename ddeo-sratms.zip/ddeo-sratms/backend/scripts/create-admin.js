// Controlled creation of the first Education Office super administrator.
// Usage: ADMIN_USERNAME=... ADMIN_PASSWORD=... node scripts/create-admin.js
const bcrypt = require('bcryptjs'); const { pool } = require('../src/db');
(async () => {
  const { ADMIN_USERNAME: u, ADMIN_PASSWORD: p } = process.env;
  if (!u || !p || p.length < 12) throw new Error('Set ADMIN_USERNAME and ADMIN_PASSWORD (12+ characters) in the environment.');
  const [[{ n }]] = await pool.execute(`SELECT COUNT(*) n FROM users WHERE role='super_admin'`);
  if (n > 0) throw new Error('A super administrator already exists. Create further accounts from the application.');
  await pool.execute(`INSERT INTO users (school_id,username,full_name,password_hash,role,must_change_password) VALUES (NULL,?,?,?, 'super_admin',1)`, [u, 'Education Office Administrator', await bcrypt.hash(p, 12)]);
  console.log('Super administrator created. You must change the password at first sign-in.');
  await pool.end();
})().catch((e) => { console.error(e.message); process.exit(1); });
