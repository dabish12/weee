const test = require('node:test'); const assert = require('node:assert/strict');
const A = require('../services/academic');

test('weights must total exactly 100', () => {
  assert.ok(A.validateWeights([{ weight: 20 }, { weight: 30 }, { weight: 50 }]));
  assert.throws(() => A.validateWeights([{ weight: 20 }, { weight: 30 }, { weight: 49.99 }]));
  assert.throws(() => A.validateWeights([{ weight: 33.33 }, { weight: 33.33 }, { weight: 33.33 }]));
  assert.ok(A.validateWeights([{ weight: 33.33 }, { weight: 33.33 }, { weight: 33.34 }]));
});
test('score range validation', () => {
  assert.equal(A.validateScore(10, 10), 10);
  assert.throws(() => A.validateScore(-1, 10)); assert.throws(() => A.validateScore(10.5, 10)); assert.throws(() => A.validateScore('x', 10));
});
test('weighted subject mark', () => {
  const comps = [{ id: 1, weight: 20, max_score: 10 }, { id: 2, weight: 30, max_score: 20 }, { id: 3, weight: 50, max_score: 50 }];
  assert.equal(A.weightedSubjectMark(comps, { 1: 10, 2: 10, 3: 25 }), 60); // 20 + 15 + 25
  assert.throws(() => A.weightedSubjectMark(comps, { 1: 10, 2: 10 }), /incomplete/);
});
test('annual score is the mean of the two semesters', () => {
  assert.equal(A.annualSubjectScore(80, 70), 75); assert.equal(A.annualSubjectScore(61.5, 70), 65.75);
});
test('ranking tie methods', () => {
  const rows = [{ id: 'a', total: 90 }, { id: 'b', total: 80 }, { id: 'c', total: 80 }, { id: 'd', total: 70 }];
  assert.deepEqual(A.rankStudents(rows, 'competition').map((r) => r.rank), [1, 2, 2, 4]);
  assert.deepEqual(A.rankStudents(rows, 'dense').map((r) => r.rank), [1, 2, 2, 3]);
  assert.throws(() => A.rankStudents(rows, undefined));
});
test('grade scale and promotion are config-driven, never assumed', () => {
  assert.equal(A.gradeFor(85, null), null);
  assert.equal(A.gradeFor(85, [{ min: 0, grade: 'F' }, { min: 80, grade: 'X' }]), 'X');
  assert.equal(A.promotionDecision([60, 40], 50, null), 'UNCONFIGURED');
  assert.equal(A.promotionDecision([60, 40], 50, { passMark: 50, maxFailedSubjects: 0 }), 'REPEAT');
  assert.equal(A.promotionDecision([60, 70], 65, { passMark: 50, maxFailedSubjects: 0 }), 'PROMOTED');
});
