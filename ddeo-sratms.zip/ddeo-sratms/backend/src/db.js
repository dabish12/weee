const mysql = require('mysql2/promise');
const cfg = require('./config');
const pool = mysql.createPool(cfg.db);

// Runs fn(conn) inside a transaction; rolls back on any error.
async function tx(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const out = await fn(conn);
    await conn.commit();
    return out;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}
module.exports = { pool, tx };
