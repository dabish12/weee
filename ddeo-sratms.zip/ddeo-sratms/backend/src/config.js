const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const e = process.env;
module.exports = {
  port: Number(e.PORT) || 3000,
  isProd: e.NODE_ENV === 'production',
  sessionHours: Number(e.SESSION_HOURS) || 8,
  frontendDir: path.join(__dirname, '..', '..', 'frontend'),
  db: {
    host: e.DB_HOST || '127.0.0.1',
    port: Number(e.DB_PORT) || 3306,
    user: e.DB_USER,
    password: e.DB_PASSWORD,
    database: e.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    decimalNumbers: true,
  },
};
