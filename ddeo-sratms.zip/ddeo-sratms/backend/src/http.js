const { ZodError } = require('zod');
class HttpError extends Error {
  constructor(status, message, code) { super(message); this.status = status; this.code = code; }
}
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
// Parses and validates input with a zod schema; throws a 400 with field messages.
const parse = (schema, data) => {
  try { return schema.parse(data); }
  catch (e) {
    if (e instanceof ZodError) throw new HttpError(400, e.issues.map(i => `${i.path.join('.')}: ${i.message}`).join('; '), 'VALIDATION');
    throw e;
  }
};
module.exports = { HttpError, wrap, parse };
