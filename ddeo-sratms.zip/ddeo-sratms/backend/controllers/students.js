const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { z } = require('zod');
const { pool, tx } = require('../src/db');
const { HttpError, wrap, parse } = require('../src/http');
const { audit } = require('../services/audit');

const studentSchema = z.object({
  studentCode: z.string().min(1).max(40).regex(/^[A-Za-z0-9\-\/]+$/, 'letters, digits, - and / only'),
  firstName: z.string().min(1).max(80), fatherName: z.string().min(1).max(80), grandfatherName: z.string().max(80).optional(),
  sex: z.enum(['M', 'F']), dateOfBirth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'use YYYY-MM-DD'),
  academicYearId: z.number().int().optional(), sectionId: z.number().int().optional(),
  confirmPossibleDuplicate: z.boolean().optional(),
});

exports.create = wrap(async (req, res) => {
  const b = parse(studentSchema, req.body);
  if (!!b.academicYearId !== !!b.sectionId) throw new HttpError(400, 'Provide both academic year and section, or neither.');
  const [dups] = await pool.execute('SELECT id, student_code FROM students WHERE school_id=? AND first_name=? AND father_name=? AND date_of_birth=?', [req.schoolId, b.firstName, b.fatherName, b.dateOfBirth]);
  if (dups.length && !b.confirmPossibleDuplicate) throw new HttpError(409, `A student with the same name and birth date already exists (ID ${dups[0].student_code}). Confirm if this is a different student.`, 'POSSIBLE_DUPLICATE');
  const id = await tx(async (c) => {
    const [r] = await c.execute('INSERT INTO students (school_id,student_code,first_name,father_name,grandfather_name,sex,date_of_birth) VALUES (?,?,?,?,?,?,?)',
      [req.schoolId, b.studentCode, b.firstName, b.fatherName, b.grandfatherName || null, b.sex, b.dateOfBirth]);
    if (b.sectionId) await c.execute('INSERT INTO enrollments (school_id,student_id,academic_year_id,section_id) VALUES (?,?,?,?)', [req.schoolId, r.insertId, b.academicYearId, b.sectionId]);
    await audit(req, 'student_create', 'student', r.insertId, { code: b.studentCode }, c);
    return r.insertId;
  });
  res.status(201).json({ id });
});

exports.update = wrap(async (req, res) => {
  const b = parse(studentSchema.pick({ firstName: true, fatherName: true, grandfatherName: true, sex: true, dateOfBirth: true }), req.body);
  const [r] = await pool.execute('UPDATE students SET first_name=?, father_name=?, grandfather_name=?, sex=?, date_of_birth=? WHERE id=? AND school_id=?',
    [b.firstName, b.fatherName, b.grandfatherName || null, b.sex, b.dateOfBirth, Number(req.params.id), req.schoolId]);
  if (!r.affectedRows) throw new HttpError(404, 'Student not found.');
  await audit(req, 'student_update', 'student', req.params.id, b);
  res.json({ ok: true });
});

exports.enroll = wrap(async (req, res) => {
  const b = parse(z.object({ academicYearId: z.number().int(), sectionId: z.number().int() }), req.body);
  await tx(async (c) => {
    const [[s]] = await c.execute('SELECT status FROM students WHERE id=? AND school_id=? FOR UPDATE', [Number(req.params.id), req.schoolId]);
    if (!s) throw new HttpError(404, 'Student not found.');
    if (s.status !== 'active') throw new HttpError(409, 'Only active students can be enrolled.');
    await c.execute('INSERT INTO enrollments (school_id,student_id,academic_year_id,section_id) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE section_id=VALUES(section_id)', [req.schoolId, Number(req.params.id), b.academicYearId, b.sectionId]);
    await audit(req, 'student_enroll', 'student', req.params.id, b, c);
  });
  res.json({ ok: true });
});

const EVENTS = { transfer: 'transferred', withdrawal: 'withdrawn', graduation: 'graduated', reactivation: 'active' };
exports.changeStatus = wrap(async (req, res) => {
  const b = parse(z.object({ event: z.enum(['transfer', 'withdrawal', 'graduation', 'reactivation']), note: z.string().max(500).optional() }), req.body);
  await tx(async (c) => {
    const [r] = await c.execute('UPDATE students SET status=? WHERE id=? AND school_id=?', [EVENTS[b.event], Number(req.params.id), req.schoolId]);
    if (!r.affectedRows) throw new HttpError(404, 'Student not found.');
    await c.execute('INSERT INTO student_status_history (school_id,student_id,event,note,changed_by) VALUES (?,?,?,?,?)', [req.schoolId, Number(req.params.id), b.event, b.note || null, req.user.id]);
    await audit(req, 'student_status', 'student', req.params.id, b, c);
  });
  res.json({ ok: true });
});

exports.createAccount = wrap(async (req, res) => {
  const pw = crypto.randomBytes(9).toString('base64url') + 'aA1';
  const out = await tx(async (c) => {
    const [[s]] = await c.execute('SELECT student_code, first_name, father_name, user_id FROM students WHERE id=? AND school_id=? FOR UPDATE', [Number(req.params.id), req.schoolId]);
    if (!s) throw new HttpError(404, 'Student not found.');
    if (s.user_id) throw new HttpError(409, 'This student already has an account.');
    const [u] = await c.execute(`INSERT INTO users (school_id,username,full_name,password_hash,role,must_change_password) VALUES (?,?,?,?, 'student',1)`,
      [req.schoolId, `s-${req.schoolId}-${s.student_code}`.toLowerCase(), `${s.first_name} ${s.father_name}`, await bcrypt.hash(pw, 12)]);
    await c.execute('UPDATE students SET user_id=? WHERE id=?', [u.insertId, Number(req.params.id)]);
    await audit(req, 'student_account_create', 'student', req.params.id, null, c);
    return `s-${req.schoolId}-${s.student_code}`.toLowerCase();
  });
  res.status(201).json({ username: out, temporaryPassword: pw });
});

const csvCell = (v) => {
  let s = v == null ? '' : String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // neutralise spreadsheet formula injection
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

exports.roster = wrap(async (req, res) => {
  const q = parse(z.object({
    yearId: z.coerce.number().int(), grade: z.coerce.number().int().min(9).max(12).optional(), sectionId: z.coerce.number().int().optional(),
    status: z.enum(['active', 'transferred', 'withdrawn', 'graduated']).optional(), q: z.string().max(80).optional(),
    sort: z.enum(['name', 'code', 'section']).default('name'), page: z.coerce.number().int().min(1).default(1),
    pageSize: z.coerce.number().int().min(1).max(200).default(25), format: z.enum(['json', 'csv']).default('json'),
  }), req.query);
  const where = ['st.school_id=?']; const args = [req.schoolId];
  // joined enrollment for the year
  let from = `FROM students st JOIN enrollments e ON e.student_id=st.id AND e.academic_year_id=? JOIN sections sec ON sec.id=e.section_id`;
  const fromArgs = [q.yearId];
  if (req.user.role === 'homeroom_teacher') { where.push('e.section_id IN (SELECT section_id FROM teacher_assignments WHERE teacher_id=? AND is_homeroom=1 AND academic_year_id=?)'); args.push(req.user.id, q.yearId); }
  if (q.grade) { where.push('sec.grade=?'); args.push(q.grade); }
  if (q.sectionId) { where.push('e.section_id=?'); args.push(q.sectionId); }
  if (q.status) { where.push('st.status=?'); args.push(q.status); }
  if (q.q) { where.push('(st.first_name LIKE ? OR st.father_name LIKE ? OR st.student_code LIKE ?)'); const l = `%${q.q.replace(/[%_]/g, '')}%`; args.push(l, l, l); }
  const order = { name: 'st.first_name, st.father_name', code: 'st.student_code', section: 'sec.grade, sec.name, st.first_name' }[q.sort];
  const w = where.join(' AND ');
  const cols = `st.id, st.student_code, st.first_name, st.father_name, st.grandfather_name, st.sex, st.date_of_birth, st.status, sec.grade, sec.name AS section, sec.stream`;
  if (q.format === 'csv') {
    const [rows] = await pool.execute(`SELECT ${cols} ${from} WHERE ${w} ORDER BY ${order}`, [...fromArgs, ...args]);
    const head = ['Student ID', 'First name', 'Father name', 'Grandfather name', 'Sex', 'Date of birth', 'Status', 'Grade', 'Section'];
    const lines = [head.join(','), ...rows.map((r) => [r.student_code, r.first_name, r.father_name, r.grandfather_name, r.sex, r.date_of_birth instanceof Date ? r.date_of_birth.toISOString().slice(0, 10) : r.date_of_birth, r.status, r.grade, r.section].map(csvCell).join(','))];
    await audit(req, 'roster_export', 'roster', null, { rows: rows.length });
    res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="roster.csv"' });
    return res.send('\ufeff' + lines.join('\r\n'));
  }
  const [[{ total }]] = await pool.execute(`SELECT COUNT(*) AS total ${from} WHERE ${w}`, [...fromArgs, ...args]);
  const off = (q.page - 1) * q.pageSize;
  const [rows] = await pool.execute(`SELECT ${cols} ${from} WHERE ${w} ORDER BY ${order} LIMIT ${q.pageSize} OFFSET ${off}`, [...fromArgs, ...args]);
  res.json({ total, page: q.page, pageSize: q.pageSize, rows });
});
