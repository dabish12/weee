const crypto = require('crypto');
const { pool, tx } = require('../src/db');
const { HttpError, wrap } = require('../src/http');
const { audit } = require('../services/audit');

async function build(conn, schoolId, studentId) {
  const [[st]] = await conn.execute(`SELECT st.id, st.student_code, st.first_name, st.father_name, st.grandfather_name, st.sex, st.date_of_birth, st.status, sc.name AS school_name, sc.code AS school_code
    FROM students st JOIN schools sc ON sc.id=st.school_id WHERE st.id=? AND st.school_id=?`, [studentId, schoolId]);
  if (!st) throw new HttpError(404, 'Student not found.');
  const [years] = await conn.execute(`SELECT ay.label, sec.grade, sec.name AS section, sec.stream, ar.total, ar.average, ar.class_rank, ar.decision, ar.details
    FROM annual_results ar JOIN academic_years ay ON ay.id=ar.academic_year_id JOIN sections sec ON sec.id=ar.section_id
    WHERE ar.school_id=? AND ar.student_id=? ORDER BY sec.grade, ay.label`, [schoolId, studentId]);
  return { student: st, years: years.map((y) => ({ ...y, subjects: y.details.subjects, details: undefined })) };
}

exports.preview = wrap(async (req, res) => {
  res.json(await build(pool, req.schoolId, Number(req.params.id)));
});

exports.issue = wrap(async (req, res) => {
  const out = await tx(async (c) => {
    const snap = await build(c, req.schoolId, Number(req.params.id));
    if (!snap.years.length) throw new HttpError(409, 'There are no computed annual results to issue.');
    const serial = `DDEO-${req.schoolId}-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
    const [r] = await c.execute('INSERT INTO transcripts (school_id,student_id,serial,snapshot,issued_by) VALUES (?,?,?,?,?)', [req.schoolId, Number(req.params.id), serial, JSON.stringify(snap), req.user.id]);
    await audit(req, 'transcript_issue', 'transcript', r.insertId, { serial }, c);
    return { id: r.insertId, serial };
  });
  res.status(201).json(out);
});

exports.listIssued = wrap(async (req, res) => {
  const [rows] = await pool.execute('SELECT id, serial, issued_at FROM transcripts WHERE school_id=? AND student_id=? ORDER BY id DESC', [req.schoolId, Number(req.params.id)]);
  res.json(rows);
});

// Public, rate-limited, deliberately minimal: confirms a serial exists, without marks.
exports.verify = wrap(async (req, res) => {
  const [rows] = await pool.execute(`SELECT t.serial, t.issued_at, sc.name AS school, st.first_name, st.father_name FROM transcripts t
    JOIN schools sc ON sc.id=t.school_id JOIN students st ON st.id=t.student_id WHERE t.serial=?`, [String(req.params.serial).slice(0, 40)]);
  if (!rows.length) throw new HttpError(404, 'No transcript was issued with this serial.');
  const r = rows[0];
  res.json({ valid: true, serial: r.serial, school: r.school, issuedAt: r.issued_at, studentName: `${r.first_name} ${r.father_name}` });
});

// Student: own results only (resolved from the session, never from a request parameter).
exports.myResults = wrap(async (req, res) => {
  const [[st]] = await pool.execute('SELECT id FROM students WHERE user_id=? AND school_id=?', [req.user.id, req.schoolId]);
  if (!st) throw new HttpError(404, 'No student record is linked to this account.');
  res.json(await build(pool, req.schoolId, st.id));
});
