// Schools, users, and academic setup (years, sections, subjects, assignments).
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { z } = require('zod');
const { pool, tx } = require('../src/db');
const { HttpError, wrap, parse } = require('../src/http');
const { audit } = require('../services/audit');
const { strongPw } = require('./auth');

const status = z.enum(['active', 'suspended', 'inactive']);
const tempPassword = () => crypto.randomBytes(9).toString('base64url') + 'aA1';

exports.listSchools = wrap(async (req, res) => {
  const [rows] = await pool.execute(`SELECT s.id, s.code, s.name, s.woreda, s.status,
    (SELECT COUNT(*) FROM students st WHERE st.school_id=s.id AND st.status='active') AS active_students FROM schools s ORDER BY s.name`);
  res.json(rows);
});
exports.createSchool = wrap(async (req, res) => {
  const b = parse(z.object({ code: z.string().min(2).max(30), name: z.string().min(2).max(150), woreda: z.string().max(100).optional() }), req.body);
  const [r] = await pool.execute('INSERT INTO schools (code,name,woreda) VALUES (?,?,?)', [b.code, b.name, b.woreda || null]);
  await audit(req, 'school_create', 'school', r.insertId, b);
  res.status(201).json({ id: r.insertId });
});
exports.setSchoolStatus = wrap(async (req, res) => {
  const { status: st } = parse(z.object({ status }), req.body);
  const [r] = await pool.execute('UPDATE schools SET status=? WHERE id=?', [st, Number(req.params.id)]);
  if (!r.affectedRows) throw new HttpError(404, 'School not found.');
  await audit(req, 'school_status', 'school', req.params.id, { status: st });
  res.json({ ok: true });
});
exports.createSchoolAdmin = wrap(async (req, res) => {
  const b = parse(z.object({ username: z.string().min(3).max(60), fullName: z.string().min(2).max(150) }), req.body);
  const pw = tempPassword();
  const [r] = await pool.execute(`INSERT INTO users (school_id,username,full_name,password_hash,role,must_change_password) VALUES (?,?,?,?, 'school_admin',1)`,
    [Number(req.params.id), b.username, b.fullName, await bcrypt.hash(pw, 12)]);
  await audit(req, 'school_admin_create', 'user', r.insertId);
  res.status(201).json({ id: r.insertId, temporaryPassword: pw }); // shown once
});

// ---- users within the admin's own school ----
exports.listUsers = wrap(async (req, res) => {
  const [rows] = await pool.execute('SELECT id, username, full_name, role, status FROM users WHERE school_id=? ORDER BY role, full_name', [req.schoolId]);
  res.json(rows);
});
exports.createUser = wrap(async (req, res) => {
  const b = parse(z.object({ username: z.string().min(3).max(60), fullName: z.string().min(2).max(150), role: z.enum(['homeroom_teacher', 'subject_teacher']) }), req.body);
  const pw = tempPassword();
  const [r] = await pool.execute('INSERT INTO users (school_id,username,full_name,password_hash,role,must_change_password) VALUES (?,?,?,?,?,1)',
    [req.schoolId, b.username, b.fullName, await bcrypt.hash(pw, 12), b.role]);
  await audit(req, 'user_create', 'user', r.insertId, { role: b.role });
  res.status(201).json({ id: r.insertId, temporaryPassword: pw });
});
exports.resetPassword = wrap(async (req, res) => {
  const pw = tempPassword();
  const [r] = await pool.execute(`UPDATE users SET password_hash=?, must_change_password=1, failed_attempts=0, locked_until=NULL
    WHERE id=? AND school_id=? AND role<>'school_admin'`, [await bcrypt.hash(pw, 12), Number(req.params.id), req.schoolId]);
  if (!r.affectedRows) throw new HttpError(404, 'User not found in your school.');
  await pool.execute('DELETE FROM sessions WHERE user_id=?', [Number(req.params.id)]);
  await audit(req, 'password_reset', 'user', req.params.id);
  res.json({ temporaryPassword: pw });
});
exports.setUserStatus = wrap(async (req, res) => {
  const { status: st } = parse(z.object({ status }), req.body);
  const [r] = await pool.execute(`UPDATE users SET status=? WHERE id=? AND school_id=? AND role NOT IN ('school_admin','super_admin')`, [st, Number(req.params.id), req.schoolId]);
  if (!r.affectedRows) throw new HttpError(404, 'User not found in your school.');
  if (st !== 'active') await pool.execute('DELETE FROM sessions WHERE user_id=?', [Number(req.params.id)]);
  await audit(req, 'user_status', 'user', req.params.id, { status: st });
  res.json({ ok: true });
});

// ---- academic setup: tiny whitelist-based CRUD (school_id always comes from the session) ----
const SETUP = {
  years: { table: 'academic_years', schema: z.object({ label: z.string().min(4).max(20), is_current: z.boolean().optional() }), cols: ['label', 'is_current'] },
  sections: { table: 'sections', schema: z.object({ grade: z.number().int().min(9).max(12), name: z.string().min(1).max(20), stream: z.enum(['none', 'natural_science', 'social_science']).default('none') }), cols: ['grade', 'name', 'stream'] },
  subjects: { table: 'subjects', schema: z.object({ name: z.string().min(2).max(100), grade: z.number().int().min(9).max(12), stream: z.enum(['none', 'natural_science', 'social_science']).default('none') }), cols: ['name', 'grade', 'stream'] },
};
exports.setupList = (key) => wrap(async (req, res) => {
  const [rows] = await pool.execute(`SELECT * FROM ${SETUP[key].table} WHERE school_id=? ORDER BY id`, [req.schoolId]);
  res.json(rows);
});
exports.setupCreate = (key) => wrap(async (req, res) => {
  const s = SETUP[key]; const b = parse(s.schema, req.body);
  const [r] = await tx(async (c) => {
    if (key === 'years' && b.is_current) await c.execute('UPDATE academic_years SET is_current=0 WHERE school_id=?', [req.schoolId]);
    const out = await c.execute(`INSERT INTO ${s.table} (school_id, ${s.cols.join(',')}) VALUES (?, ${s.cols.map(() => '?').join(',')})`, [req.schoolId, ...s.cols.map((k) => b[k] ?? null)]);
    await audit(req, `${key}_create`, s.table, out[0].insertId, b, c);
    return out;
  });
  res.status(201).json({ id: r.insertId });
});

exports.listAssignments = wrap(async (req, res) => {
  const mine = ['homeroom_teacher', 'subject_teacher'].includes(req.user.role);
  const [rows] = await pool.execute(`SELECT a.id, a.academic_year_id, a.section_id, a.subject_id, a.is_homeroom, a.teacher_id, u.full_name AS teacher,
      sec.grade, sec.name AS section, sub.name AS subject
    FROM teacher_assignments a JOIN users u ON u.id=a.teacher_id JOIN sections sec ON sec.id=a.section_id LEFT JOIN subjects sub ON sub.id=a.subject_id
    WHERE a.school_id=? ${mine ? 'AND a.teacher_id=?' : ''} ORDER BY sec.grade, sec.name`, mine ? [req.schoolId, req.user.id] : [req.schoolId]);
  res.json(rows);
});
exports.createAssignment = wrap(async (req, res) => {
  const b = parse(z.object({ academicYearId: z.number().int(), teacherId: z.number().int(), sectionId: z.number().int(), subjectId: z.number().int().nullable(), isHomeroom: z.boolean().default(false) }), req.body);
  const [[t]] = await pool.execute('SELECT role FROM users WHERE id=? AND school_id=?', [b.teacherId, req.schoolId]);
  if (!t || !['homeroom_teacher', 'subject_teacher'].includes(t.role)) throw new HttpError(400, 'Choose a teacher from your school.');
  if (b.isHomeroom ? b.subjectId !== null : b.subjectId === null) throw new HttpError(400, 'Homeroom assignments have no subject; subject assignments need one.');
  const [r] = await pool.execute('INSERT INTO teacher_assignments (school_id,academic_year_id,teacher_id,section_id,subject_id,is_homeroom) VALUES (?,?,?,?,?,?)',
    [req.schoolId, b.academicYearId, b.teacherId, b.sectionId, b.subjectId, b.isHomeroom ? 1 : 0]);
  await audit(req, 'assignment_create', 'teacher_assignment', r.insertId, b);
  res.status(201).json({ id: r.insertId });
});

exports.getConfig = wrap(async (req, res) => {
  const [rows] = await pool.execute('SELECT config_key, config_value FROM system_config');
  res.json(Object.fromEntries(rows.map((r) => [r.config_key, r.config_value])));
});
const CONFIG_SCHEMAS = {
  grading_scale: z.array(z.object({ min: z.number(), grade: z.string().min(1).max(5) })).min(1),
  promotion_rule: z.object({ passMark: z.number(), maxFailedSubjects: z.number().int().optional(), minAverage: z.number().optional() }),
  graduation_rule: z.object({ minAverage: z.number().optional(), notes: z.string().max(500).optional() }),
  ranking_method: z.enum(['competition', 'dense']),
};
exports.setConfig = wrap(async (req, res) => {
  const schema = CONFIG_SCHEMAS[req.params.key];
  if (!schema) throw new HttpError(400, 'Unknown setting.');
  const v = parse(schema, req.body.value);
  await pool.execute('INSERT INTO system_config (config_key, config_value, updated_by) VALUES (?,?,?) ON DUPLICATE KEY UPDATE config_value=VALUES(config_value), updated_by=VALUES(updated_by)', [req.params.key, JSON.stringify(v), req.user.id]);
  await audit(req, 'config_set', 'system_config', req.params.key, v);
  res.json({ ok: true });
});

exports.stats = wrap(async (req, res) => {
  if (!req.user.school_id) {
    const [[a]] = await pool.execute(`SELECT (SELECT COUNT(*) FROM schools) schools, (SELECT COUNT(*) FROM students WHERE status='active') students, (SELECT COUNT(*) FROM users WHERE role IN ('homeroom_teacher','subject_teacher')) teachers`);
    const [bySchool] = await pool.execute(`SELECT s.name, COUNT(st.id) AS students FROM schools s LEFT JOIN students st ON st.school_id=s.id AND st.status='active' GROUP BY s.id ORDER BY s.name`);
    return res.json({ ...a, bySchool });
  }
  const [[a]] = await pool.execute(`SELECT (SELECT COUNT(*) FROM students WHERE school_id=? AND status='active') students,
    (SELECT COUNT(*) FROM users WHERE school_id=? AND role IN ('homeroom_teacher','subject_teacher')) teachers,
    (SELECT COUNT(*) FROM mark_sheets WHERE school_id=? AND status='submitted') pendingApprovals`, [req.schoolId, req.schoolId, req.schoolId]);
  res.json(a);
});

exports.listAudit = wrap(async (req, res) => {
  const [rows] = req.user.school_id
    ? await pool.execute('SELECT id, user_id, action, entity, entity_id, created_at FROM audit_logs WHERE school_id=? ORDER BY id DESC LIMIT 200', [req.schoolId])
    : await pool.execute('SELECT id, school_id, user_id, action, entity, entity_id, created_at FROM audit_logs ORDER BY id DESC LIMIT 200');
  res.json(rows);
});
