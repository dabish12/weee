const { z } = require('zod');
const { pool, tx } = require('../src/db');
const { HttpError, wrap, parse } = require('../src/http');
const { audit } = require('../services/audit');
const A = require('../services/academic');

async function config(conn, key) {
  const [r] = await conn.execute('SELECT config_value FROM system_config WHERE config_key=?', [key]);
  return r.length ? r[0].config_value : null;
}

exports.putComponents = wrap(async (req, res) => {
  const b = parse(z.object({ academicYearId: z.number().int(), semester: z.number().int().min(1).max(2), grade: z.number().int().min(9).max(12),
    components: z.array(z.object({ name: z.string().min(1).max(60), weight: z.number().positive().max(100), max_score: z.number().positive().max(1000) })).min(1).max(10) }), req.body);
  try { A.validateWeights(b.components); } catch (e) { throw new HttpError(400, e.message, 'WEIGHTS'); }
  await tx(async (c) => {
    const [[m]] = await c.execute(`SELECT COUNT(*) n FROM marks m JOIN assessment_components ac ON ac.id=m.component_id
      WHERE ac.school_id=? AND ac.academic_year_id=? AND ac.semester=? AND ac.grade=?`, [req.schoolId, b.academicYearId, b.semester, b.grade]);
    if (m.n) throw new HttpError(409, 'Marks already exist for these components, so the weights are locked.', 'LOCKED');
    await c.execute('DELETE FROM assessment_components WHERE school_id=? AND academic_year_id=? AND semester=? AND grade=?', [req.schoolId, b.academicYearId, b.semester, b.grade]);
    for (const k of b.components) await c.execute('INSERT INTO assessment_components (school_id,academic_year_id,semester,grade,name,weight,max_score) VALUES (?,?,?,?,?,?,?)', [req.schoolId, b.academicYearId, b.semester, b.grade, k.name, k.weight, k.max_score]);
    await audit(req, 'components_set', 'assessment_components', null, b, c);
  });
  res.json({ ok: true });
});

exports.getComponents = wrap(async (req, res) => {
  const q = parse(z.object({ yearId: z.coerce.number().int(), semester: z.coerce.number().int(), grade: z.coerce.number().int() }), req.query);
  const [rows] = await pool.execute('SELECT id, name, weight, max_score FROM assessment_components WHERE school_id=? AND academic_year_id=? AND semester=? AND grade=? ORDER BY id', [req.schoolId, q.yearId, q.semester, q.grade]);
  res.json(rows);
});

// Teacher may touch a sheet only with a matching assignment; admins may access any sheet in their school.
async function openSheet(req, conn, { yearId, semester, sectionId, subjectId }, create) {
  if (req.user.role === 'subject_teacher') {
    const [a] = await conn.execute('SELECT id FROM teacher_assignments WHERE school_id=? AND teacher_id=? AND academic_year_id=? AND section_id=? AND subject_id=?', [req.schoolId, req.user.id, yearId, sectionId, subjectId]);
    if (!a.length) throw new HttpError(403, 'You are not assigned to this subject and class.', 'FORBIDDEN');
  } else if (req.user.role !== 'school_admin') throw new HttpError(403, 'You do not have permission for this action.', 'FORBIDDEN');
  if (create) await conn.execute('INSERT IGNORE INTO mark_sheets (school_id,academic_year_id,semester,section_id,subject_id) VALUES (?,?,?,?,?)', [req.schoolId, yearId, semester, sectionId, subjectId]);
  const [[s]] = await conn.execute('SELECT ms.*, sec.grade FROM mark_sheets ms JOIN sections sec ON sec.id=ms.section_id WHERE ms.school_id=? AND ms.academic_year_id=? AND ms.semester=? AND ms.section_id=? AND ms.subject_id=?' + (create ? '' : ' FOR UPDATE'), [req.schoolId, yearId, semester, sectionId, subjectId]);
  if (!s) throw new HttpError(404, 'Mark sheet not found.');
  return s;
}
const keySchema = z.object({ yearId: z.coerce.number().int(), semester: z.coerce.number().int().min(1).max(2), sectionId: z.coerce.number().int(), subjectId: z.coerce.number().int() });

async function sheetData(conn, schoolId, s) {
  const [components] = await conn.execute('SELECT id, name, weight, max_score FROM assessment_components WHERE school_id=? AND academic_year_id=? AND semester=? AND grade=? ORDER BY id', [schoolId, s.academic_year_id, s.semester, s.grade]);
  const [students] = await conn.execute(`SELECT st.id, st.student_code, st.first_name, st.father_name FROM enrollments e JOIN students st ON st.id=e.student_id
    WHERE e.school_id=? AND e.academic_year_id=? AND e.section_id=? AND st.status='active' ORDER BY st.first_name, st.father_name`, [schoolId, s.academic_year_id, s.section_id]);
  const [marks] = await conn.execute('SELECT student_id, component_id, score FROM marks WHERE sheet_id=? AND school_id=?', [s.id, schoolId]);
  return { components, students, marks };
}

exports.getSheet = wrap(async (req, res) => {
  const k = parse(keySchema, req.query);
  const s = await openSheet(req, pool, k, true);
  res.json({ sheet: { id: s.id, status: s.status, grade: s.grade }, ...(await sheetData(pool, req.schoolId, s)) });
});

exports.saveMarks = wrap(async (req, res) => {
  const b = parse(z.object({ ...keySchema.shape, entries: z.array(z.object({ studentId: z.number().int(), componentId: z.number().int(), score: z.number() })).min(1).max(5000) }), { ...req.body });
  await tx(async (c) => {
    const s = await openSheet(req, c, b, true);
    if (s.status !== 'draft') throw new HttpError(409, 'Submitted or approved marks cannot be changed by teachers.', 'SEALED');
    const d = await sheetData(c, req.schoolId, s);
    const comp = new Map(d.components.map((x) => [x.id, x])); const stu = new Set(d.students.map((x) => x.id));
    for (const e of b.entries) {
      const k = comp.get(e.componentId);
      if (!k || !stu.has(e.studentId)) throw new HttpError(400, 'An entry refers to a student or component outside this sheet.');
      try { A.validateScore(e.score, k.max_score); } catch (err) { throw new HttpError(400, `${k.name}: ${err.message}`, 'INVALID_MARK'); }
      await c.execute('INSERT INTO marks (school_id,sheet_id,student_id,component_id,score) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE score=VALUES(score)', [req.schoolId, s.id, e.studentId, e.componentId, e.score]);
    }
    await audit(req, 'marks_save', 'mark_sheet', s.id, { entries: b.entries.length }, c);
  });
  res.json({ ok: true });
});

async function computeTotals(c, schoolId, s) {
  const d = await sheetData(c, schoolId, s);
  A.validateWeights(d.components);
  const byStudent = new Map();
  for (const m of d.marks) { if (!byStudent.has(m.student_id)) byStudent.set(m.student_id, {}); byStudent.get(m.student_id)[m.component_id] = m.score; }
  return d.students.map((st) => ({ studentId: st.id, total: A.weightedSubjectMark(d.components, byStudent.get(st.id) || {}) }));
}

exports.submitSheet = wrap(async (req, res) => {
  const b = parse(keySchema, req.body);
  await tx(async (c) => {
    const s = await openSheet(req, c, b, false);
    if (s.status !== 'draft') throw new HttpError(409, 'This sheet was already submitted.');
    let totals;
    try { totals = await computeTotals(c, req.schoolId, s); } catch (e) { throw new HttpError(400, e.message, 'INCOMPLETE'); }
    if (!totals.length) throw new HttpError(400, 'No active students are enrolled in this class.');
    await c.execute('DELETE FROM subject_results WHERE sheet_id=?', [s.id]);
    for (const t of totals) await c.execute('INSERT INTO subject_results (school_id,sheet_id,student_id,total) VALUES (?,?,?,?)', [req.schoolId, s.id, t.studentId, t.total]);
    await c.execute(`UPDATE mark_sheets SET status='submitted', submitted_by=?, submitted_at=NOW() WHERE id=?`, [req.user.id, s.id]);
    await audit(req, 'sheet_submit', 'mark_sheet', s.id, null, c);
  });
  res.json({ ok: true });
});

exports.reviewSheet = (decision) => wrap(async (req, res) => {
  const b = parse(keySchema, req.body);
  await tx(async (c) => {
    const s = await openSheet(req, c, b, false);
    if (s.status !== 'submitted') throw new HttpError(409, 'Only submitted sheets can be reviewed.');
    if (decision === 'approve') await c.execute(`UPDATE mark_sheets SET status='approved', approved_by=?, approved_at=NOW() WHERE id=?`, [req.user.id, s.id]);
    else { await c.execute(`UPDATE mark_sheets SET status='draft' WHERE id=?`, [s.id]); await c.execute('DELETE FROM subject_results WHERE sheet_id=?', [s.id]); }
    if (s.submitted_by) await c.execute('INSERT INTO notifications (user_id, message) VALUES (?,?)', [s.submitted_by, decision === 'approve' ? 'Your submitted marks were approved.' : 'Your submitted marks were returned for correction.']);
    await audit(req, `sheet_${decision}`, 'mark_sheet', s.id, null, c);
  });
  res.json({ ok: true });
});

// Authorised correction of a sealed sheet: reason required, old and new values audited.
exports.correctMark = wrap(async (req, res) => {
  const b = parse(z.object({ ...keySchema.shape, studentId: z.number().int(), componentId: z.number().int(), score: z.number(), reason: z.string().min(5).max(300) }), req.body);
  await tx(async (c) => {
    const s = await openSheet(req, c, b, false);
    if (s.status === 'draft') throw new HttpError(409, 'Draft marks are edited by the teacher, not corrected.');
    const [[k]] = await c.execute('SELECT * FROM assessment_components WHERE id=? AND school_id=? AND academic_year_id=? AND semester=? AND grade=?', [b.componentId, req.schoolId, s.academic_year_id, s.semester, s.grade]);
    if (!k) throw new HttpError(400, 'Component does not belong to this sheet.');
    try { A.validateScore(b.score, k.max_score); } catch (e) { throw new HttpError(400, e.message, 'INVALID_MARK'); }
    const [[old]] = await c.execute('SELECT score FROM marks WHERE sheet_id=? AND student_id=? AND component_id=?', [s.id, b.studentId, b.componentId]);
    if (!old) throw new HttpError(404, 'No existing mark to correct.');
    await c.execute('UPDATE marks SET score=? WHERE sheet_id=? AND student_id=? AND component_id=?', [b.score, s.id, b.studentId, b.componentId]);
    const totals = await computeTotals(c, req.schoolId, s);
    for (const t of totals) await c.execute('UPDATE subject_results SET total=? WHERE sheet_id=? AND student_id=?', [t.total, s.id, t.studentId]);
    await audit(req, 'mark_correction', 'mark_sheet', s.id, { studentId: b.studentId, componentId: b.componentId, from: old.score, to: b.score, reason: b.reason }, c);
  });
  res.json({ ok: true });
});

// Annual results for one section. Only approved Semester I and II sheets count.
exports.computeAnnual = wrap(async (req, res) => {
  const b = parse(z.object({ academicYearId: z.number().int(), sectionId: z.number().int() }), req.body);
  const out = await tx(async (c) => {
    const method = await config(c, 'ranking_method');
    if (!method) throw new HttpError(409, 'The ranking method has not been configured by the Education Office.', 'UNCONFIGURED');
    const scale = await config(c, 'grading_scale'); const promo = await config(c, 'promotion_rule'); const grad = await config(c, 'graduation_rule');
    const [[sec]] = await c.execute('SELECT * FROM sections WHERE id=? AND school_id=?', [b.sectionId, req.schoolId]);
    if (!sec) throw new HttpError(404, 'Section not found.');
    const [subjects] = await c.execute(`SELECT id, name FROM subjects WHERE school_id=? AND grade=? AND stream IN ('none', ?)`, [req.schoolId, sec.grade, sec.stream]);
    if (!subjects.length) throw new HttpError(409, 'No subjects are defined for this grade and stream.');
    const [res_] = await c.execute(`SELECT ms.subject_id, ms.semester, ms.status, sr.student_id, sr.total FROM mark_sheets ms LEFT JOIN subject_results sr ON sr.sheet_id=ms.id
      WHERE ms.school_id=? AND ms.academic_year_id=? AND ms.section_id=?`, [req.schoolId, b.academicYearId, b.sectionId]);
    const missing = [];
    for (const sub of subjects) for (const sem of [1, 2]) if (!res_.some((r) => r.subject_id === sub.id && r.semester === sem && r.status === 'approved')) missing.push(`${sub.name} (Semester ${sem})`);
    if (missing.length) throw new HttpError(409, `Approved results are missing for: ${missing.join(', ')}.`, 'INCOMPLETE');
    const [students] = await c.execute(`SELECT st.id FROM enrollments e JOIN students st ON st.id=e.student_id WHERE e.school_id=? AND e.academic_year_id=? AND e.section_id=? AND st.status='active'`, [req.schoolId, b.academicYearId, b.sectionId]);
    const rows = students.map((st) => {
      const subs = subjects.map((sub) => {
        const g = (sem) => { const r = res_.find((x) => x.subject_id === sub.id && x.semester === sem && x.student_id === st.id); return r ? r.total : null; };
        const s1 = g(1), s2 = g(2);
        if (s1 === null || s2 === null) throw new HttpError(409, 'A student is missing a result; re-open the sheet.', 'INCOMPLETE');
        const annual = A.annualSubjectScore(s1, s2);
        return { subject: sub.name, s1, s2, annual, grade: A.gradeFor(annual, scale) };
      });
      const total = Math.round(subs.reduce((x, y) => x + y.annual, 0) * 100) / 100;
      return { studentId: st.id, subs, total, average: Math.round((total / subs.length) * 100) / 100 };
    });
    const ranked = A.rankStudents(rows, method);
    for (const r of ranked) {
      let decision;
      if (sec.grade === 12) decision = !grad || typeof grad.minAverage !== 'number' ? 'UNCONFIGURED' : (r.average >= grad.minAverage ? 'GRADUATE' : 'NOT_GRADUATE');
      else decision = A.promotionDecision(r.subs.map((x) => x.annual), r.average, promo);
      await c.execute(`INSERT INTO annual_results (school_id,academic_year_id,student_id,section_id,total,average,class_rank,decision,details) VALUES (?,?,?,?,?,?,?,?,?)
        ON DUPLICATE KEY UPDATE section_id=VALUES(section_id), total=VALUES(total), average=VALUES(average), class_rank=VALUES(class_rank), decision=VALUES(decision), details=VALUES(details), computed_at=NOW()`,
        [req.schoolId, b.academicYearId, r.studentId, b.sectionId, r.total, r.average, r.rank, decision, JSON.stringify({ subjects: r.subs })]);
    }
    await audit(req, 'annual_compute', 'section', b.sectionId, { year: b.academicYearId, students: ranked.length }, c);
    return ranked.length;
  });
  res.json({ computed: out });
});

exports.listAnnual = wrap(async (req, res) => {
  const q = parse(z.object({ yearId: z.coerce.number().int(), sectionId: z.coerce.number().int() }), req.query);
  if (req.user.role === 'homeroom_teacher') {
    const [a] = await pool.execute('SELECT id FROM teacher_assignments WHERE school_id=? AND teacher_id=? AND academic_year_id=? AND section_id=? AND is_homeroom=1', [req.schoolId, req.user.id, q.yearId, q.sectionId]);
    if (!a.length) throw new HttpError(403, 'You can only view your own homeroom class.', 'FORBIDDEN');
  }
  const [rows] = await pool.execute(`SELECT ar.student_id, st.student_code, st.first_name, st.father_name, ar.total, ar.average, ar.class_rank, ar.decision
    FROM annual_results ar JOIN students st ON st.id=ar.student_id WHERE ar.school_id=? AND ar.academic_year_id=? AND ar.section_id=? ORDER BY ar.class_rank, st.first_name`, [req.schoolId, q.yearId, q.sectionId]);
  res.json(rows);
});
