const bcrypt = require('bcryptjs');
const { z } = require('zod');
const { pool } = require('../src/db');
const { HttpError, wrap, parse } = require('../src/http');
const { createSession, destroySession } = require('../middleware/auth');
const { audit } = require('../services/audit');

const DUMMY = bcrypt.hashSync('not-a-real-password', 12);
const strongPw = z.string().min(10, 'at least 10 characters').max(100)
  .regex(/[a-z]/, 'needs a lowercase letter').regex(/[A-Z]/, 'needs an uppercase letter').regex(/[0-9]/, 'needs a number');

exports.strongPw = strongPw;

exports.login = wrap(async (req, res) => {
  const { username, password } = parse(z.object({ username: z.string().min(1).max(60), password: z.string().min(1).max(100) }), req.body);
  const [rows] = await pool.execute('SELECT * FROM users WHERE username=?', [username]);
  const u = rows[0];
  if (u && u.locked_until && new Date(u.locked_until) > new Date()) throw new HttpError(429, 'Too many failed attempts. Try again later.', 'LOCKED');
  const ok = await bcrypt.compare(password, u ? u.password_hash : DUMMY);
  if (!u || !ok) {
    if (u) await pool.execute('UPDATE users SET failed_attempts=failed_attempts+1, locked_until=IF(failed_attempts+1>=5, DATE_ADD(NOW(), INTERVAL 15 MINUTE), NULL) WHERE id=?', [u.id]);
    throw new HttpError(401, 'Username or password is incorrect.', 'BAD_LOGIN');
  }
  if (u.status !== 'active') throw new HttpError(403, 'This account is not active.', 'ACCOUNT_INACTIVE');
  await pool.execute('UPDATE users SET failed_attempts=0, locked_until=NULL WHERE id=?', [u.id]);
  const csrf = await createSession(req, res, u.id);
  req.user = u; await audit(req, 'login', 'user', u.id);
  res.json({ csrf, user: pub(u) });
});

const pub = (u) => ({ id: u.id, username: u.username, fullName: u.full_name, role: u.role, schoolId: u.school_id, mustChangePassword: !!u.must_change_password });

exports.me = (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in.' });
  res.json({ csrf: req.csrf, user: pub(req.user) });
};

exports.logout = wrap(async (req, res) => { await destroySession(req, res); res.json({ ok: true }); });

exports.changePassword = wrap(async (req, res) => {
  const { current, next } = parse(z.object({ current: z.string().max(100), next: strongPw }), req.body);
  const [[u]] = await pool.execute('SELECT password_hash FROM users WHERE id=?', [req.user.id]);
  if (!(await bcrypt.compare(current, u.password_hash))) throw new HttpError(400, 'Current password is incorrect.', 'BAD_CURRENT');
  await pool.execute('UPDATE users SET password_hash=?, must_change_password=0 WHERE id=?', [await bcrypt.hash(next, 12), req.user.id]);
  // end every other session for this user
  await pool.execute('DELETE FROM sessions WHERE user_id=? AND csrf_token<>?', [req.user.id, req.csrf]);
  await audit(req, 'password_change', 'user', req.user.id);
  res.json({ ok: true });
});
