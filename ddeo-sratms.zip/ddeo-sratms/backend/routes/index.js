const express = require('express');
const rateLimit = require('express-rate-limit');
const { requireAuth, requireRole, schoolScope } = require('../middleware/auth');
const auth = require('../controllers/auth');
const admin = require('../controllers/admin');
const students = require('../controllers/students');
const asm = require('../controllers/assessments');
const tr = require('../controllers/transcripts');

const r = express.Router();
const SUPER = requireRole('super_admin');
const ADMIN = requireRole('school_admin');
const STAFF = requireRole('school_admin', 'homeroom_teacher', 'subject_teacher');

// public
r.post('/auth/login', rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many attempts. Try again later.' } }), auth.login);
r.get('/auth/me', auth.me);
r.get('/verify/:serial', rateLimit({ windowMs: 60 * 1000, limit: 20 }), tr.verify);

// everything below needs a valid session (+ CSRF on writes)
r.use(requireAuth);
r.post('/auth/logout', auth.logout);
r.post('/auth/change-password', auth.changePassword);

// Education Office
r.get('/schools', SUPER, admin.listSchools);
r.post('/schools', SUPER, admin.createSchool);
r.patch('/schools/:id/status', SUPER, admin.setSchoolStatus);
r.post('/schools/:id/admin', SUPER, admin.createSchoolAdmin);
r.get('/config', SUPER, admin.getConfig);
r.put('/config/:key', SUPER, admin.setConfig);
r.get('/stats', requireRole('super_admin', 'school_admin'), admin.stats);
r.get('/audit', requireRole('super_admin', 'school_admin'), admin.listAudit);

// school workspace (school_id always comes from the session)
r.use(schoolScope);
r.get('/users', ADMIN, admin.listUsers);
r.post('/users', ADMIN, admin.createUser);
r.post('/users/:id/reset-password', ADMIN, admin.resetPassword);
r.patch('/users/:id/status', ADMIN, admin.setUserStatus);

for (const k of ['years', 'sections', 'subjects']) { r.get(`/${k}`, STAFF, admin.setupList(k)); r.post(`/${k}`, ADMIN, admin.setupCreate(k)); }
r.get('/assignments', STAFF, admin.listAssignments);
r.post('/assignments', ADMIN, admin.createAssignment);

r.get('/roster', requireRole('school_admin', 'homeroom_teacher'), students.roster);
r.post('/students', ADMIN, students.create);
r.patch('/students/:id', ADMIN, students.update);
r.post('/students/:id/enroll', ADMIN, students.enroll);
r.post('/students/:id/status', ADMIN, students.changeStatus);
r.post('/students/:id/account', ADMIN, students.createAccount);

r.get('/components', STAFF, asm.getComponents);
r.put('/components', ADMIN, asm.putComponents);
r.get('/marksheet', requireRole('school_admin', 'subject_teacher'), asm.getSheet);
r.put('/marksheet/marks', requireRole('subject_teacher'), asm.saveMarks);
r.post('/marksheet/submit', requireRole('subject_teacher'), asm.submitSheet);
r.post('/marksheet/approve', ADMIN, asm.reviewSheet('approve'));
r.post('/marksheet/return', ADMIN, asm.reviewSheet('return'));
r.post('/marksheet/correct', ADMIN, asm.correctMark);
r.post('/results/annual/compute', ADMIN, asm.computeAnnual);
r.get('/results/annual', requireRole('school_admin', 'homeroom_teacher'), asm.listAnnual);

r.get('/transcripts/student/:id', ADMIN, tr.preview);
r.post('/transcripts/student/:id/issue', ADMIN, tr.issue);
r.get('/transcripts/student/:id/issued', ADMIN, tr.listIssued);
r.get('/me/results', requireRole('student'), tr.myResults);

module.exports = r;
