-- DDEO-SRATMS schema (MySQL 8+, InnoDB, utf8mb4)
CREATE DATABASE IF NOT EXISTS ddeo_sratms CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE ddeo_sratms;

CREATE TABLE schools (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(30) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  woreda VARCHAR(100) NULL,
  logo_path VARCHAR(255) NULL,
  status ENUM('active','suspended','inactive') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NULL,
  username VARCHAR(60) NOT NULL UNIQUE,
  full_name VARCHAR(150) NOT NULL,
  password_hash VARCHAR(100) NOT NULL,
  role ENUM('super_admin','school_admin','homeroom_teacher','subject_teacher','student') NOT NULL,
  status ENUM('active','suspended','inactive') NOT NULL DEFAULT 'active',
  must_change_password TINYINT(1) NOT NULL DEFAULT 1,
  failed_attempts INT NOT NULL DEFAULT 0,
  locked_until DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_users_school FOREIGN KEY (school_id) REFERENCES schools(id),
  CONSTRAINT chk_users_school CHECK ((role='super_admin' AND school_id IS NULL) OR (role<>'super_admin' AND school_id IS NOT NULL)),
  INDEX idx_users_school_role (school_id, role)
) ENGINE=InnoDB;

CREATE TABLE sessions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  token_hash CHAR(64) NOT NULL UNIQUE,
  user_id INT UNSIGNED NOT NULL,
  csrf_token CHAR(48) NOT NULL,
  ip VARCHAR(64) NULL,
  expires_at DATETIME NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_sessions_exp (expires_at)
) ENGINE=InnoDB;

CREATE TABLE academic_years (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NOT NULL,
  label VARCHAR(20) NOT NULL,
  is_current TINYINT(1) NOT NULL DEFAULT 0,
  UNIQUE KEY uq_year (school_id, label),
  UNIQUE KEY uq_year_school (id, school_id),
  FOREIGN KEY (school_id) REFERENCES schools(id)
) ENGINE=InnoDB;

CREATE TABLE sections (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NOT NULL,
  grade TINYINT UNSIGNED NOT NULL,
  name VARCHAR(20) NOT NULL,
  stream ENUM('none','natural_science','social_science') NOT NULL DEFAULT 'none',
  UNIQUE KEY uq_section (school_id, grade, name),
  UNIQUE KEY uq_section_school (id, school_id),
  FOREIGN KEY (school_id) REFERENCES schools(id),
  CONSTRAINT chk_grade CHECK (grade BETWEEN 9 AND 12)
) ENGINE=InnoDB;

CREATE TABLE subjects (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NOT NULL,
  name VARCHAR(100) NOT NULL,
  grade TINYINT UNSIGNED NOT NULL,
  stream ENUM('none','natural_science','social_science') NOT NULL DEFAULT 'none',
  UNIQUE KEY uq_subject (school_id, name, grade, stream),
  UNIQUE KEY uq_subject_school (id, school_id),
  FOREIGN KEY (school_id) REFERENCES schools(id)
) ENGINE=InnoDB;

-- subject_id NULL + is_homeroom=1 => homeroom teacher of the section
CREATE TABLE teacher_assignments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NOT NULL,
  academic_year_id INT UNSIGNED NOT NULL,
  teacher_id INT UNSIGNED NOT NULL,
  section_id INT UNSIGNED NOT NULL,
  subject_id INT UNSIGNED NULL,
  is_homeroom TINYINT(1) NOT NULL DEFAULT 0,
  FOREIGN KEY (school_id) REFERENCES schools(id),
  FOREIGN KEY (teacher_id) REFERENCES users(id),
  FOREIGN KEY (section_id, school_id) REFERENCES sections(id, school_id),
  FOREIGN KEY (subject_id, school_id) REFERENCES subjects(id, school_id),
  FOREIGN KEY (academic_year_id, school_id) REFERENCES academic_years(id, school_id),
  INDEX idx_assign_teacher (teacher_id, academic_year_id)
) ENGINE=InnoDB;

CREATE TABLE students (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NULL UNIQUE,
  student_code VARCHAR(40) NOT NULL,
  first_name VARCHAR(80) NOT NULL,
  father_name VARCHAR(80) NOT NULL,
  grandfather_name VARCHAR(80) NULL,
  sex ENUM('M','F') NOT NULL,
  date_of_birth DATE NOT NULL,
  photo_path VARCHAR(255) NULL,
  status ENUM('active','transferred','withdrawn','graduated') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_student_code (school_id, student_code),
  UNIQUE KEY uq_student_school (id, school_id),
  FOREIGN KEY (school_id) REFERENCES schools(id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  INDEX idx_student_name (school_id, first_name, father_name)
) ENGINE=InnoDB;

CREATE TABLE enrollments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NOT NULL,
  student_id INT UNSIGNED NOT NULL,
  academic_year_id INT UNSIGNED NOT NULL,
  section_id INT UNSIGNED NOT NULL,
  UNIQUE KEY uq_enroll (student_id, academic_year_id),
  FOREIGN KEY (student_id, school_id) REFERENCES students(id, school_id),
  FOREIGN KEY (section_id, school_id) REFERENCES sections(id, school_id),
  FOREIGN KEY (academic_year_id, school_id) REFERENCES academic_years(id, school_id),
  INDEX idx_enroll_section (section_id, academic_year_id)
) ENGINE=InnoDB;

CREATE TABLE student_status_history (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NOT NULL,
  student_id INT UNSIGNED NOT NULL,
  event ENUM('transfer','withdrawal','graduation','promotion','reactivation') NOT NULL,
  note VARCHAR(500) NULL,
  changed_by INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id, school_id) REFERENCES students(id, school_id)
) ENGINE=InnoDB;

CREATE TABLE assessment_components (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NOT NULL,
  academic_year_id INT UNSIGNED NOT NULL,
  semester TINYINT UNSIGNED NOT NULL,
  grade TINYINT UNSIGNED NOT NULL,
  name VARCHAR(60) NOT NULL,
  weight DECIMAL(5,2) NOT NULL,
  max_score DECIMAL(6,2) NOT NULL,
  UNIQUE KEY uq_comp (school_id, academic_year_id, semester, grade, name),
  FOREIGN KEY (academic_year_id, school_id) REFERENCES academic_years(id, school_id),
  CONSTRAINT chk_sem CHECK (semester IN (1,2)),
  CONSTRAINT chk_w CHECK (weight > 0 AND weight <= 100 AND max_score > 0)
) ENGINE=InnoDB;

CREATE TABLE mark_sheets (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NOT NULL,
  academic_year_id INT UNSIGNED NOT NULL,
  semester TINYINT UNSIGNED NOT NULL,
  section_id INT UNSIGNED NOT NULL,
  subject_id INT UNSIGNED NOT NULL,
  status ENUM('draft','submitted','approved') NOT NULL DEFAULT 'draft',
  submitted_by INT UNSIGNED NULL, submitted_at DATETIME NULL,
  approved_by INT UNSIGNED NULL, approved_at DATETIME NULL,
  UNIQUE KEY uq_sheet (academic_year_id, semester, section_id, subject_id),
  UNIQUE KEY uq_sheet_school (id, school_id),
  FOREIGN KEY (section_id, school_id) REFERENCES sections(id, school_id),
  FOREIGN KEY (subject_id, school_id) REFERENCES subjects(id, school_id),
  FOREIGN KEY (academic_year_id, school_id) REFERENCES academic_years(id, school_id)
) ENGINE=InnoDB;

CREATE TABLE marks (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NOT NULL,
  sheet_id INT UNSIGNED NOT NULL,
  student_id INT UNSIGNED NOT NULL,
  component_id INT UNSIGNED NOT NULL,
  score DECIMAL(6,2) NOT NULL,
  UNIQUE KEY uq_mark (sheet_id, student_id, component_id),
  FOREIGN KEY (sheet_id, school_id) REFERENCES mark_sheets(id, school_id),
  FOREIGN KEY (student_id, school_id) REFERENCES students(id, school_id),
  FOREIGN KEY (component_id) REFERENCES assessment_components(id)
) ENGINE=InnoDB;

CREATE TABLE subject_results (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NOT NULL,
  sheet_id INT UNSIGNED NOT NULL,
  student_id INT UNSIGNED NOT NULL,
  total DECIMAL(6,2) NOT NULL,
  UNIQUE KEY uq_sr (sheet_id, student_id),
  FOREIGN KEY (sheet_id, school_id) REFERENCES mark_sheets(id, school_id),
  FOREIGN KEY (student_id, school_id) REFERENCES students(id, school_id)
) ENGINE=InnoDB;

CREATE TABLE annual_results (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NOT NULL,
  academic_year_id INT UNSIGNED NOT NULL,
  student_id INT UNSIGNED NOT NULL,
  section_id INT UNSIGNED NOT NULL,
  total DECIMAL(8,2) NOT NULL,
  average DECIMAL(6,2) NOT NULL,
  class_rank INT UNSIGNED NOT NULL,
  decision VARCHAR(30) NOT NULL,
  details JSON NOT NULL,
  computed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_ar (academic_year_id, student_id),
  FOREIGN KEY (student_id, school_id) REFERENCES students(id, school_id),
  FOREIGN KEY (academic_year_id, school_id) REFERENCES academic_years(id, school_id)
) ENGINE=InnoDB;

CREATE TABLE attendance (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NOT NULL,
  student_id INT UNSIGNED NOT NULL,
  academic_year_id INT UNSIGNED NOT NULL,
  semester TINYINT UNSIGNED NOT NULL,
  on_date DATE NOT NULL,
  status ENUM('present','absent','late','excused') NOT NULL,
  conduct_note VARCHAR(300) NULL,
  recorded_by INT UNSIGNED NOT NULL,
  UNIQUE KEY uq_att (student_id, on_date),
  FOREIGN KEY (student_id, school_id) REFERENCES students(id, school_id)
) ENGINE=InnoDB;

CREATE TABLE registration_requests (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NOT NULL,
  student_id INT UNSIGNED NOT NULL,
  academic_year_id INT UNSIGNED NOT NULL,
  requested_grade TINYINT UNSIGNED NOT NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  decided_by INT UNSIGNED NULL, decided_at DATETIME NULL, note VARCHAR(300) NULL,
  FOREIGN KEY (student_id, school_id) REFERENCES students(id, school_id)
) ENGINE=InnoDB;

CREATE TABLE transcripts (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NOT NULL,
  student_id INT UNSIGNED NOT NULL,
  serial VARCHAR(40) NOT NULL UNIQUE,
  snapshot JSON NOT NULL,
  issued_by INT UNSIGNED NOT NULL,
  issued_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id, school_id) REFERENCES students(id, school_id)
) ENGINE=InnoDB;

CREATE TABLE notifications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  message VARCHAR(300) NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  school_id INT UNSIGNED NULL,
  user_id INT UNSIGNED NULL,
  action VARCHAR(60) NOT NULL,
  entity VARCHAR(40) NULL,
  entity_id VARCHAR(40) NULL,
  detail JSON NULL,
  ip VARCHAR(64) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_school (school_id, created_at)
) ENGINE=InnoDB;

-- Global rules set by the Education Office. NOT pre-filled: grading scale,
-- promotion rule and graduation rule must come from approved policy.
CREATE TABLE system_config (
  config_key VARCHAR(60) PRIMARY KEY,
  config_value JSON NOT NULL,
  updated_by INT UNSIGNED NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;
