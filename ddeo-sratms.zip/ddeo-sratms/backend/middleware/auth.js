const crypto = require('crypto');
const { pool } = require('../src/db');
const cfg = require('../src/config');
const { HttpError, wrap } = require('../src/http');

const sha = (t) => crypto.createHash('sha256').update(t).digest('hex');

async function createSession(req, res, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  const csrf = crypto.randomBytes(24).toString('hex');
  const expires = new Date(Date.now() + cfg.sessionHours * 3600 * 1000);
  await pool.execute(
    'INSERT INTO sessions (token_hash, user_id, csrf_token, expires_at, ip) VALUES (?,?,?,?,?)',
    [sha(token), userId, csrf, expires, req.ip]);
  res.cookie('sid', token, { httpOnly: true, secure: cfg.isProd, sameSite: 'strict', expires, path: '/' });
  return csrf;
}

async function destroySession(req, res) {
  if (req.cookies && req.cookies.sid) await pool.execute('DELETE FROM sessions WHERE token_hash=?', [sha(req.cookies.sid)]);
  res.clearCookie('sid', { path: '/' });
}

// Loads the session + user (always from the database, never trusting the client).
const loadSession = wrap(async (req, res, next) => {
  const t = req.cookies && req.cookies.sid;
  if (!t) return next();
  const [rows] = await pool.execute(
    `SELECT u.id, u.role, u.school_id, u.full_name, u.username, u.status, u.must_change_password,
            s.csrf_token, sc.status AS school_status
       FROM sessions s JOIN users u ON u.id = s.user_id
       LEFT JOIN schools sc ON sc.id = u.school_id
      WHERE s.token_hash = ? AND s.expires_at > NOW()`, [sha(t)]);
  if (rows.length) { req.user = rows[0]; req.csrf = rows[0].csrf_token; }
  next();
});

const requireAuth = (req, res, next) => {
  if (!req.user) return next(new HttpError(401, 'Sign in to continue.', 'UNAUTHENTICATED'));
  const u = req.user;
  if (u.status !== 'active') return next(new HttpError(403, 'This account is not active.', 'ACCOUNT_INACTIVE'));
  if (u.school_id && u.school_status !== 'active') return next(new HttpError(403, 'This school account is not active.', 'SCHOOL_INACTIVE'));
  if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    const sent = Buffer.from(String(req.get('x-csrf-token') || ''));
    const real = Buffer.from(req.csrf);
    if (sent.length !== real.length || !crypto.timingSafeEqual(sent, real)) return next(new HttpError(403, 'Invalid security token. Refresh the page.', 'CSRF'));
  }
  if (u.must_change_password && !req.path.startsWith('/auth/')) return next(new HttpError(403, 'Change your password to continue.', 'PASSWORD_CHANGE_REQUIRED'));
  next();
};

const requireRole = (...roles) => (req, res, next) =>
  roles.includes(req.user.role) ? next() : next(new HttpError(403, 'You do not have permission for this action.', 'FORBIDDEN'));

// Sets req.schoolId from the session. Super admins have no school, so school-scoped routes reject them.
const schoolScope = (req, res, next) => {
  if (!req.user.school_id) return next(new HttpError(403, 'This action belongs to a school workspace.', 'NO_SCHOOL'));
  req.schoolId = req.user.school_id;
  next();
};

module.exports = { createSession, destroySession, loadSession, requireAuth, requireRole, schoolScope };
