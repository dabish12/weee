const cfg = require('../src/config');
exports.notFound = (req, res) => res.status(404).json({ error: 'Not found.' });
exports.errorHandler = (err, req, res, next) => {
  if (err.status) return res.status(err.status).json({ error: err.message, code: err.code });
  if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'A record with these details already exists.', code: 'DUPLICATE' });
  if (err.code === 'ER_NO_REFERENCED_ROW_2' || err.code === 'ER_ROW_IS_REFERENCED_2') return res.status(409).json({ error: 'The record refers to data that does not exist in this school.', code: 'REFERENCE' });
  console.error(err); // details stay in the server log only
  res.status(500).json({ error: 'Something went wrong on the server.', ...(cfg.isProd ? {} : { debug: err.message }) });
};
