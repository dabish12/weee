const { pool } = require('../src/db');
// conn can be a transaction connection so the audit row commits with the change.
async function audit(req, action, entity, entityId, detail, conn = pool) {
  await conn.execute(
    'INSERT INTO audit_logs (school_id, user_id, action, entity, entity_id, detail, ip) VALUES (?,?,?,?,?,?,?)',
    [req.user ? req.user.school_id : null, req.user ? req.user.id : null, action, entity || null,
     entityId == null ? null : String(entityId), detail ? JSON.stringify(detail) : null, req.ip]);
}
module.exports = { audit };
