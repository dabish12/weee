// Pure academic calculations. No grading scale, ranking tie rule, promotion threshold
// or graduation rule is hard-coded: these come from officially approved configuration.
const cents = (n) => Math.round(Number(n) * 100);

function validateWeights(components) {
  if (!components.length) throw new Error('At least one assessment component is required.');
  const total = components.reduce((s, c) => s + cents(c.weight), 0);
  if (total !== 10000) throw new Error(`Assessment weights must total exactly 100% (currently ${total / 100}%).`);
  return true;
}

function validateScore(score, max) {
  const n = Number(score);
  if (score === '' || score === null || Number.isNaN(n)) throw new Error('Score must be a number.');
  if (n < 0 || n > Number(max)) throw new Error(`Score must be between 0 and ${max}.`);
  return n;
}

// components: [{id, weight, max_score}]; scores: {componentId: score}. Result is out of 100.
function weightedSubjectMark(components, scores) {
  validateWeights(components);
  let sum = 0;
  for (const c of components) {
    if (scores[c.id] === undefined) throw new Error('Marks are incomplete.');
    sum += (validateScore(scores[c.id], c.max_score) / Number(c.max_score)) * Number(c.weight);
  }
  return Math.round(sum * 100) / 100;
}

// Equal-weight semesters: (S1 + S2) / 2
const annualSubjectScore = (s1, s2) => Math.round(((Number(s1) + Number(s2)) / 2) * 100) / 100;

// method comes from configuration: 'competition' (1,2,2,4) | 'dense' (1,2,2,3)
function rankStudents(rows, method) {
  if (!['competition', 'dense'].includes(method)) throw new Error('Ranking method is not configured.');
  const sorted = [...rows].sort((a, b) => b.total - a.total);
  let rank = 0, prev = null, seen = 0;
  return sorted.map((r) => {
    seen++;
    if (r.total !== prev) { rank = method === 'dense' ? rank + 1 : seen; prev = r.total; }
    return { ...r, rank };
  });
}

// scale: [{min, grade}] from configuration. Returns null when no scale is configured.
function gradeFor(score, scale) {
  if (!Array.isArray(scale) || !scale.length) return null;
  const hit = [...scale].sort((a, b) => b.min - a.min).find((b) => score >= b.min);
  return hit ? hit.grade : null;
}

// rule: {passMark, maxFailedSubjects, minAverage?} from configuration.
function promotionDecision(subjectScores, average, rule) {
  if (!rule || typeof rule.passMark !== 'number') return 'UNCONFIGURED';
  const failed = subjectScores.filter((s) => s < rule.passMark).length;
  if (typeof rule.maxFailedSubjects === 'number' && failed > rule.maxFailedSubjects) return 'REPEAT';
  if (typeof rule.minAverage === 'number' && average < rule.minAverage) return 'REPEAT';
  return 'PROMOTED';
}

module.exports = { validateWeights, validateScore, weightedSubjectMark, annualSubjectScore, rankStudents, gradeFor, promotionDecision };
